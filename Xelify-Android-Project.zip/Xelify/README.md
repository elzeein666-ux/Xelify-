# Xelify — Pixel Music Player

Native Android music player built with Kotlin, Jetpack Compose, and AndroidX Media3 (ExoPlayer). This is an Android project, not an HTML website.

## Current features
- Pixel-inspired dark interface with mint accents
- Import local audio using Android's document picker
- Play, pause, previous, next
- Home and library screens
- Local playback without an internet connection after audio files are on the device

## Build APK
1. Open this project in Android Studio (Hedgehog or newer).
2. Let Gradle sync finish.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is at `app/build/outputs/apk/debug/app-debug.apk`.

## GitHub Actions
The included workflow builds a debug APK on pushes to `main` or when manually started from the Actions tab. Download the `Xelify-debug-apk` artifact from the workflow run.

## Notes
- This first version plays audio files selected by the user. It does not stream Spotify's catalog or provide Spotify account integration.
- This is a starter build; test on a physical Android device before wider distribution.
