package com.xelify.music

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Night = Color(0xFF10151D)
private val Panel = Color(0xFF1B2531)
private val Mint = Color(0xFF9EF5B5)
private val Muted = Color(0xFF9AA8B8)

data class Track(val uri: Uri, val title: String, val artist: String)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            XelifyApp(
                player = player!!,
                onPickAudio = { launcher ->
                    launcher.launch(arrayOf("audio/*"))
                }
            )
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@Composable
private fun XelifyApp(player: ExoPlayer, onPickAudio: (androidx.activity.result.ActivityResultLauncher<Array<String>>) -> Unit) {
    val tracks = remember { mutableStateListOf<Track>() }
    var current by remember { mutableIntStateOf(-1) }
    var playing by remember { mutableStateOf(false) }
    var tab by remember { mutableStateOf("HOME") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            try {
                // Persist access so imported tracks remain readable after reopening the app.
                // Some document providers may not support persistable grants; ignore those failures.
                tracks.add(Track(uri, uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Unknown track", "Local audio"))
            } catch (_: Exception) { }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, background = Night, surface = Panel,
        onPrimary = Night, onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(modifier = Modifier.fillMaxSize(), color = Night) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(22.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("XELIFY", color = Mint, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("PIXEL MUSIC PLAYER", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                    }
                    Text("▣", color = Mint, fontSize = 28.sp)
                }
                Spacer(Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("HOME", "LIBRARY").forEach { item ->
                        Box(
                            Modifier.background(if (tab == item) Mint else Panel, RoundedCornerShape(8.dp))
                                .clickable { tab = item }.padding(horizontal = 16.dp, vertical = 10.dp)
                        ) {
                            Text(item, color = if (tab == item) Night else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { picker.launch(arrayOf("audio/*")) }) {
                        Icon(Icons.Default.Add, contentDescription = "Import music", tint = Mint)
                    }
                }
                Spacer(Modifier.height(18.dp))
                if (tab == "HOME") {
                    Text("YOUR SOUNDTRACK", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(10.dp))
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(16.dp)) {
                        Box(Modifier.fillMaxWidth().height(126.dp).background(Color(0xFF263D46), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                            Text("♫  ░▒▓  ♫", color = Mint, fontSize = 30.sp, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text(if (current >= 0 && current < tracks.size) tracks[current].title else "Midnight Pixel", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (current >= 0 && current < tracks.size) tracks[current].artist else "Your next favorite sound", color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = {
                                if (tracks.isNotEmpty()) {
                                    current = if (current <= 0) tracks.lastIndex else current - 1
                                    playTrack(player, tracks, current); playing = true
                                }
                            }) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
                            FilledIconButton(onClick = {
                                if (current >= 0 && current < tracks.size) {
                                    if (player.isPlaying) { player.pause(); playing = false }
                                    else { player.play(); playing = true }
                                } else if (tracks.isNotEmpty()) {
                                    current = 0; playTrack(player, tracks, current); playing = true
                                } else picker.launch(arrayOf("audio/*"))
                            }, colors = IconButtonDefaults.filledIconButtonColors(containerColor = Mint, contentColor = Night), modifier = Modifier.size(54.dp)) {
                                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
                            }
                            IconButton(onClick = {
                                if (tracks.isNotEmpty()) {
                                    current = (current + 1).mod(tracks.size)
                                    playTrack(player, tracks, current); playing = true
                                }
                            }) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
                        }
                    }
                    Spacer(Modifier.height(22.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("QUICK PICKS", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Text("${tracks.size} TRACKS", color = Mint, fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    if (tracks.isEmpty()) {
                        EmptyState { picker.launch(arrayOf("audio/*")) }
                    } else {
                        TrackList(tracks, current) { index ->
                            current = index; playTrack(player, tracks, index); playing = true
                        }
                    }
                } else {
                    Text("YOUR LIBRARY", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(12.dp))
                    if (tracks.isEmpty()) EmptyState { picker.launch(arrayOf("audio/*")) }
                    else TrackList(tracks, current) { index ->
                        current = index; playTrack(player, tracks, index); playing = true
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("LOCAL MUSIC • OFFLINE READY", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 14.dp))
            }
        }
    }
}

private fun playTrack(player: ExoPlayer, tracks: List<Track>, index: Int) {
    val track = tracks.getOrNull(index) ?: return
    player.setMediaItem(MediaItem.fromUri(track.uri))
    player.prepare()
    player.play()
}

@Composable
private fun TrackList(tracks: List<Track>, current: Int, onClick: (Int) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
        itemsIndexed(tracks) { index, track ->
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(9.dp))
                    .clickable { onClick(index) }.padding(11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(38.dp).background(Color(0xFF29443C), RoundedCornerShape(7.dp)), contentAlignment = Alignment.Center) {
                    Text("♫", color = Mint, fontSize = 20.sp)
                }
                Spacer(Modifier.width(11.dp))
                Column(Modifier.weight(1f)) {
                    Text(track.title, color = if (index == current) Mint else Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track.artist, color = Muted, fontSize = 10.sp)
                }
                if (index == current) Icon(Icons.Default.Equalizer, null, tint = Mint)
            }
        }
    }
}

@Composable
private fun EmptyState(onImport: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("♫", color = Mint, fontSize = 32.sp)
        Spacer(Modifier.height(6.dp))
        Text("Your library is waiting", color = Color.White, fontWeight = FontWeight.Bold)
        Text("Import MP3 or other audio files from your phone.", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(12.dp))
        Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Night)) {
            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(17.dp))
            Spacer(Modifier.width(7.dp))
            Text("IMPORT MUSIC")
        }
    }
}
